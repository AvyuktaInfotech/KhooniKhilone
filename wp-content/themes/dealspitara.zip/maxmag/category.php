<?php get_header(); ?>


<div id="main">



	<div id="home-left">

		<?php if ( $paged < 2 ) : ?>

		<h3 class="category-heading"><?php single_cat_title(); ?></h3>

		<div id="featured-container">

			<div class="flexslider">

          			<ul class="slides">

					<?php $current_category = single_cat_title("", false); $category_id = get_cat_ID($current_category); $cat_posts = new WP_Query('showposts=3&cat='.$category_id); while($cat_posts->have_posts()) : $cat_posts->the_post(); $do_not_duplicate[] = $post->ID; ?>

					<?php if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) { ?>			

					<li>

						<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_post_thumbnail('slider-thumb'); ?></a>

						<div class="featured-box">

							<?php if(get_post_meta($post->ID, "maxmag_featured_headline", true)): ?>

							<h2><a href="<?php the_permalink() ?>"><?php echo get_post_meta($post->ID, "maxmag_featured_headline", true); ?></a></h2>

							<?php else: ?>

							<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>

							<?php endif; ?>

							<p><?php echo excerpt(17); ?></p>

						</div><!--featured-box-->

					</li>

					<?php } ?>

					<?php endwhile; ?>

				</ul>

			</div><!--flexslider-->

		</div><!---featured-container-->

		<?php endif; ?>

		<div class="home-widget">

			<h3>More <?php single_cat_title(); ?> News</h3>

			<ul class="category3">

			

			<?php $current_category = single_cat_title("", false); $category_id = get_cat_ID($current_category); $cat_posts = new WP_Query('showposts=3&cat='.$category_id); while($cat_posts->have_posts()) : $cat_posts->the_post(); $do_not_duplicate[] = $post->ID; ?>

			<?php endwhile; ?>



			<?php if (have_posts()) : while (have_posts()) : the_post(); if (in_array($post->ID, $do_not_duplicate)) continue; ?>

				<li>

					<?php if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) { ?>

					<div class="category3-image">

						<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_post_thumbnail('small-thumb'); ?></a>

					</div><!--category3-image-->

					<div class="category3-text">

						<a href="<?php the_permalink() ?>" class="main-headline"><?php the_title(); ?></a>

						<p><?php echo excerpt(15); ?></p>

						<div class="headlines-info">

							<ul class="headlines-info">

								<li>Posted <?php echo human_time_diff(get_the_time('U'), current_time('timestamp')) . ' ago'; ?></li>

								<li class="comments-icon"><a href="<?php comments_link(); ?>"><?php comments_number( '0', '1', '%' ); ?></a></li>

							</ul>

						</div><!--headlines-info-->

					</div><!--category3-text-->

					<?php } else { ?>

					<div class="category3-text-noimg">

						<a href="<?php the_permalink() ?>" class="main-headline"><?php the_title(); ?></a>

						<p><?php echo excerpt(15); ?></p>

						<div class="headlines-info">

							<ul class="headlines-info">

								<li>Posted <?php echo human_time_diff(get_the_time('U'), current_time('timestamp')) . ' ago'; ?></li>

								<li class="comments-icon"><a href="<?php comments_link(); ?>"><?php comments_number( '0', '1', '%' ); ?></a></li>

							</ul>

						</div><!--headlines-info-->

					</div><!--category3-text-noimg-->

					<?php } ?>

				</li>

			<?php endwhile; endif; ?>

			</ul>

		</div><!--home-widget-->

		<div class="nav-links">

			<?php posts_nav_link(' &#8212; ', __('&laquo; Previous Page'), __('Next Page &raquo;')); ?>

		</div><!--nav-links-->

	</div><!--home-left-->

	<div id="home-right" class="home-right-category">

		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Category Middle Widget Area')): endif; ?>

	</div><!--home-right-->
<div id="social-box-vert">

			<div class="post-social-vert">

				<iframe src="http://www.facebook.com/plugins/like.php?&amp;href=<?php echo urlencode(get_permalink($post->ID)); ?>&amp;send=false&amp;layout=box_count&amp;width=450&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=90" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:50px; height:60px;" allowTransparency="true"></iframe>

			</div><!--post-social-vert-->

			<div class="post-social-vert">

				<a href="https://twitter.com/share" class="twitter-share-button" data-lang="en" data-count="vertical">Tweet</a>

			</div><!--post-social-vert-->

			

			<div class="post-social-vert">

				<g:plusone size="tall"></g:plusone>

			</div><!--post-social-vert-->

		</div><!--social-box-vert-->
</div><!--main -->



<?php get_sidebar('category'); ?>

<?php get_footer(); ?>