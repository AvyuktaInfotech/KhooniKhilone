<div id="sidebar-wrapper">
	<div class="middle-side">
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Middle Widget Area')): endif; ?>
	</div><!--middle-side-->
	<div class="side">
		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar Widget Area')): endif; ?>
	</div><!--side-->
</div><!--sidebar-wrapper-->