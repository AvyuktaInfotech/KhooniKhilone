<?php get_header(); ?>



<div id="main-home">



	<div id="home-left">

		



		<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage Widget Area')): endif; ?>



	</div><!--home-left-->
<div id="social-box-vert">

			<div class="post-social-vert">

				<iframe src="//www.facebook.com/plugins/like.php?href=https%3A%2F%2Fwww.facebook.com%2FDealsPitara&amp;send=false&amp;layout=box_count&amp;width=450&amp;show_faces=false&amp;font&amp;colorscheme=light&amp;action=like&amp;height=65&amp;appId=426287864086365" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:65px;" allowTransparency="true"></iframe>

			</div><!--post-social-vert-->

			<div class="post-social-vert">

				<a href="https://twitter.com/dealspitara" class="twitter-follow-button" data-show-count="true" data-count="vertical" data-show-screen-name="false">Follow</a>
			</div><!--post-social-vert-->

			

			<div class="post-social-vert">

				<g:plusone size="tall"></g:plusone>

			</div><!--post-social-vert-->

		</div><!--social-box-vert-->
</div><!--main-home-->



<?php get_sidebar('home'); ?>



<div id="bottom-widget">

	<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('Homepage Bottom Widget Area')): endif; ?>

</div><!--bottom-widget-->



<?php get_footer(); ?>