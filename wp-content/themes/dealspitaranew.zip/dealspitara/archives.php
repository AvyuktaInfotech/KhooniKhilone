<?php
/*
Template Name: Archives
*/
?>

<?php get_header(); ?>

<div id="main">
	<div id="post-area">
		<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<h1><?php the_title(); ?></h1>
		<?php endwhile; endif; ?>
		<div id="content-area">
			<h5><?php _e( 'Archives by Month', 'mvp-text' ); ?>:</h5>
			<ul class="archives">
				<?php wp_get_archives('type=monthly'); ?>
			</ul>
		
			<h5><?php _e( 'Archives by Category', 'mvp-text' ); ?>:</h5>
			<ul class="archives">
				<?php wp_list_categories(); ?>
			</ul>
		</div>
	</div><!--post-area-->
</div><!--main -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>