<?php get_header(); ?>

<div id="main">
	<div id="post-area">
		<ul class="archive">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<li>
				<?php if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) { ?>
				<div class="archive-image">
					<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_post_thumbnail('small-thumb'); ?></a>
				</div><!--archive-image-->
				<div class="archive-text">
					<a href="<?php the_permalink() ?>" class="main-headline"><?php the_title(); ?></a>
					<p><?php echo excerpt(38); ?></p>
					<div class="headlines-info">
						<ul class="headlines-info">
							<li>Posted <?php echo human_time_diff(get_the_time('U'), current_time('timestamp')) . ' ago'; ?></li>
							<li class="comments-icon"><a href="<?php comments_link(); ?>"><?php comments_number( '0', '1', '%' ); ?></a></li>
						</ul>
					</div><!--headlines-info-->
				</div><!--archive-text-->
				<?php } else { ?>
				<div class="archive-text-noimg">
					<a href="<?php the_permalink() ?>" class="main-headline"><?php the_title(); ?></a>
					<p><?php echo excerpt(38); ?></p>
					<div class="headlines-info">
						<ul class="headlines-info">
							<li>Posted <?php echo human_time_diff(get_the_time('U'), current_time('timestamp')) . ' ago'; ?></li>
							<li class="comments-icon"><a href="<?php comments_link(); ?>"><?php comments_number( '0', '1', '%' ); ?></a></li>
						</ul>
					</div><!--headlines-info-->
				</div><!--archive-text-noimg-->
				<?php } ?>
			</li>
			<?php endwhile; endif; ?>
		</ul>
		<div class="nav-links">
			<?php posts_nav_link(' &#8212; ', __('&laquo; Previous Page'), __('Next Page &raquo;')); ?>
		</div><!--nav-links-->
	</div><!--post-area-->
</div><!--main -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>