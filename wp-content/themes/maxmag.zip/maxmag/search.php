<?php get_header(); ?>

<div id="main">
	<div id="post-area">
		<div class="breadcrumb">
			<?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
		</div><!--breadcrumb-->
		<h1 class="archive-header">Search results for "<?php the_search_query() ?>"</h1>
		<ul class="archive">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<li>
				<div class="archive-image">
					<?php if (  (function_exists('has_post_thumbnail')) && (has_post_thumbnail())  ) { ?>
					<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_post_thumbnail('small-thumb'); ?></a>
					<?php } ?>
				</div><!--archive-image-->
				<div class="archive-text">
					<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
					<p><?php echo excerpt(38); ?></p>
					<div class="headlines-info">
						<ul class="headlines-info">
							<li>Posted <?php echo human_time_diff(get_the_time('U'), current_time('timestamp')) . ' ago'; ?></li>
							<li class="comments-icon"><a href="<?php comments_link(); ?>"><?php comments_number( '0', '1', '%' ); ?></a></li>
						</ul>
					</div><!--headlines-info-->
				</div><!--archive-text-->
			</li>
			<?php endwhile; endif; ?>
		</ul>
	<?php posts_nav_link(' &#8212; ', __('&laquo; Previous Page'), __('Next Page &raquo;')); ?>
	</div><!--post-area-->
</div><!--main -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>