/* ---------------------------------
Simple:Press - Version 5.0
Base Front-end Forum Javascript

$LastChangedDate: 2010-08-11 12:22:07 -0700 (Wed, 11 Aug 2010) $
$Rev: 4384 $
------------------------------------ */

var result;

function spjLoadTool(url, target, imageFile) {
	if (imageFile != '') {
		document.getElementById(target).innerHTML = '<br /><br /><img src="' + imageFile + '" /><br />';
	}
	jQuery('#'+target).load(url);
}

function spjClearIt(target) {
	document.getElementById(target).innerHTML = '';
}

/* ----------------------------------
Validate the new post form
-------------------------------------*/
function spjValidatePostForm(theForm, guest, topic, img) {
	var reason = '';
	if (guest == 1 && theForm.guestname !='undefined') reason+= spjValidateThis(theForm.guestname, sp_forum_vars.noguestname);
	if (guest == 1 && theForm.guestemail !='undefined') reason+= spjValidateThis(theForm.guestemail, sp_forum_vars.noguestemail);
	if (topic == 1 && theForm.newtopicname !='undefined') reason+= spjValidateThis(theForm.newtopicname, sp_forum_vars.notopictitle);
	reason+= spjEdValidateContent(theForm.postitem, sp_forum_vars.nocontent);
	/* check for pasted content */
	var thisPost = spjEdGetEditorContent(theForm);
	var found = false;
	var checkWords = new Array();
	checkWords[0] = 'MsoPlainText';
	checkWords[1] = 'MsoNormal';
	checkWords[2] = 'mso-layout-grid-align';
	checkWords[3] = 'mso-pagination';
	checkWords[4] = 'white-space:';
	for (i=0; i<checkWords.length; i++) {
		if (thisPost.match(checkWords[i]) != null) {
			found = true;
		}
	}
	if (found) {
		reason += "<strong>" + sp_forum_vars.rejected + "</strong><br />";
	}
	if (thisPost.match('<iframe') || thisPost.match('&lt;iframe') != null) {
		reason += "<strong>" + sp_forum_vars.iframe + "</strong><br />";
	}

	/* any errors */
	if (reason != '') {
		var msg = sp_forum_vars.problem + '<br />' + reason;
		jQuery('#spPostNotifications').html(msg);
		jQuery('#spPostNotifications').show('slow');

		return false;
	}

	var saveBtn = document.getElementById('sfsave');
	saveBtn.value = sp_forum_vars.savingpost;
	saveBtn.disabled = 'disabled';

	var msg = '<div id="spNotification" class="spMessageSuccess"><img src="' + waitImage.src + '" alt="" />' + sp_forum_vars.savingpost + ' - ' + sp_forum_vars.wait + '</div>';
	spjDisplayNotification(msg);

	return true;
}

/* ----------------------------------
Validatation support routines
-------------------------------------*/
function spjValidateThis(theField, errorMsg) {
	var error = '';
	if (theField.value.length == 0) {
		error = '<strong>' + errorMsg + '</strong><br />';
	}
	return error;
}

/* ----------------------------------
Validatate search text has been input
-------------------------------------*/
function spjValidateSearch(c, maxLen) {
	var stopSearch = false;
	var msg = '';
	var s = jQuery('#searchvalue').val();

	if(s == '') {
		msg = sp_forum_vars.nosearch;
		spjDisplayNotification(m);
		stopSearch = true;
	} else {
		var w = s.split(" ");
		var good = 0;
		var bad = 0;
		for (i=0; i < w.length; i++) {
			if(w[i].length < maxLen ? bad++ : good++);
		}

		if(good == 0) {
			msg = sp_forum_vars.allwordmin + ' ' + maxLen;
			stopSearch = true;
		} else if(bad != 0) {
			msg = sp_forum_vars.somewordmin + ' ' + maxLen;
		}
	}
	if(msg != '') {
		var m = '<div id="spNotification" class="spMessageFailure">' + msg + '</div>';
		spjDisplayNotification(m);
	}

	if(stopSearch == false && c == 'link') {
		document.sfsearch.submit();
		return;
	}
	if(stopSearch == true) {
		return false;
	} else {
		return true;
	}
}

function spjOpenEditor(editorId, formType) {
	jQuery(document).ready(function() {
		jQuery('#'+editorId).show('slide');
		var obj = document.getElementById(editorId);
		obj.scrollIntoView();
		if (formType == 'topic') {
			document.addtopic.spTopicTitle.focus();
		} else {
			spjEdOpenEditor();
		}
	});
}

/* ----------------------------------
Open and Close of hidden divs
-------------------------------------*/
function spjToggleLayer(whichLayer, speed) {
	if (!speed) speed = 'slow';
	jQuery('#'+whichLayer).slideToggle(speed);

	var obj = document.getElementById(whichLayer);
	if (whichLayer == 'spPostForm' || whichLayer == 'sfsearchform') {
		obj.scrollIntoView();
	}
}

/* ----------------------------------
Quote Post insertion
-------------------------------------*/
function spjQuotePost(postid, intro, forumid, quoteUrl) {
	quoteUrl+='&post='+postid+'&forumid='+forumid;

	jQuery('#spPostForm').show(function() {
		jQuery('#postitem').load(quoteUrl, function(content, b) {

			/* all browsers */
			document.getElementById('spPostForm').scrollIntoView();
			spjEdInsertContent(intro, content);
		});
	});
}

/* ----------------------------------
Enable Save buttons on Math entry
-------------------------------------*/
function spjSetPostButton(result, val1, val2, gbuttontext, bbuttontext) {
	var button = document.addpost.newpost;

	if (result.value == (val1+val2)) {
		button.disabled=false;
		button.value = gbuttontext;
	} else {
		button.disabled=true;
		button.value = bbuttontext;
	}
}

function spjSetTopicButton(result, val1, val2, gbuttontext, bbuttontext) {
	var button = document.addtopic.newtopic;

	if (result.value == (val1+val2)) {
		button.disabled=false;
		button.value = gbuttontext;
	} else {
		button.disabled=true;
		button.value = bbuttontext;
	}
}

/* ----------------------------------
Trigger redirect on drop down
-------------------------------------*/
function spjChangeURL(menuObj) {
	var i = menuObj.selectedIndex;

	if (i > 0) {
 		if (menuObj.options[i].value != '#') {
			window.location = menuObj.options[i].value;
		}
	}
}

/* ----------------------------------
URL redirect
-------------------------------------*/
function spjReDirect(url) {
	window.location = url;
}

/* ----------------------------------
Error and Success top notification
-------------------------------------*/
function spjDisplayNotification($m) {
	var offset = jQuery('#spMainContainer').offset();
	jQuery('html').prepend($m);
	jQuery('#spNotification').css('left', offset.left);
	jQuery('#spNotification').show();
	jQuery('#spNotification').fadeOut(6000, function() {
		jQuery('#spNotification').remove();
	});
}

/* ----------------------------------
Auto Updates
-------------------------------------*/
function spjAutoUpdate(url, timer) {
	var sfInterval = window.setInterval("spjPerformUpdates('" + url + "')", timer);
}

function spjPerformUpdates(url) {
    updates = url.split('%');
	for (i=0; i < updates.length; i++) {
        up = updates[i].split(',');
        var str = func = up[0] + "('" + up[1] + "')";
        func = func.replace(/&amp;/gi, '&');
        eval(func);
	}
}

function spjUserUpdate(url) {
	/* still logged in? */
	var targetIDUser = document.getElementById('sfthisuser');
	if (targetIDUser != null) {
		var userid = targetIDUser.innerHTML;
		if (userid == null || userid == '') {
			userid = '0';
		}
		var userCheckUrl = url + '&target=checkuser&thisuser=' + userid + '&rnd=' +  new Date().getTime();
		jQuery('#sflogininfo').load(userCheckUrl);
	}
}

/* ----------------------------------
Embed a pre syntax highlight codeblock
-------------------------------------*/
function spjSelectCode(codeBlock) {
var e = document.getElementById(codeBlock);
	/* Get ID of code block
	   Not IE */
	if (window.getSelection) {
		var s = window.getSelection();
		/* Safari */
		if (s.setBaseAndExtent) {
			s.setBaseAndExtent(e, 0, e, e.innerText.length - 1);
		} else {
			/* Firefox and Opera */
			var r = document.createRange();
			r.selectNodeContents(e);
			s.removeAllRanges();
			s.addRange(r);
		}
	} else if (document.getSelection) {
		/* Some older browsers */
		var s = document.getSelection();
		var r = document.createRange();
		r.selectNodeContents(e);
		s.removeAllRanges();
		s.addRange(r);
	} else if (document.selection) {
		/* IE */
		var r = document.body.createTextRange();
		r.moveToElementText(e);
		r.select();
	}
}

function spjRemoveAvatar(ahahURL, avatarTarget, spinner) {
	jQuery('#'+avatarTarget).html('<img src="' + spinner + '" />');
	jQuery('#'+avatarTarget).load(ahahURL);
	jQuery('#spDeleteUploadedAvatar').hide();
	return;
}

function spjRemovePool(ahahURL, avatarTarget, spinner) {
	jQuery('#'+avatarTarget).html('<img src="' + spinner + '" />');
	jQuery('#'+avatarTarget).load(ahahURL);
	jQuery('#spDeletePoolAvatar').hide();
	return;
}

function spjRemoveNotice(ahahUrl, noticeId) {
	jQuery('#'+noticeId).slideUp();
	jQuery('#'+noticeId).load(ahahUrl);
}

function spjSelAvatar(file, msg) {
	document.getElementById('spPoolAvatar').value = file;
	jQuery('#spPoolStatus').html('<p>' + msg + '</p>');
	return;
}

function spjSpoilerToggle(id, reveal, hide) {
	spjToggleLayer('spSpoilerContent' + id, 'fast');
	cur = jQuery('#spSpoilerState' + id).val();
	if (cur == 0) {
		jQuery('#spSpoilerState' + id).val(1);
		jQuery('#spRevealLink' + id).html(hide);
	} else {
		jQuery('#spSpoilerState' + id).val(0);
		jQuery('#spRevealLink' + id).html(reveal);
	}
}

function spjGetCategories(ahahURL, checked, spinner) {
	if(checked) {
		jQuery('#spCatList').html('<img src="' + spinner + '" />');
		jQuery('#spCatList').show('slide');
		jQuery('#spCatList').load(ahahURL);
	} else {
		jQuery('#spCatList').hide();
	}
}

function spjSetProfileDataHeight() {
	baseHeight = Math.max(jQuery("#spProfileData").outerHeight(true) + 10, jQuery("#spProfileMenu").outerHeight(true));
   	jQuery("#spProfileContent").height(baseHeight + jQuery("#spProfileHeader").outerHeight(true));
}

function spjOpenCloseForums(target, tagId, tagClass, openIcon, closeIcon, toolTipOpen, toolTipClose) {
	var c=jQuery('#'+target).css('display');
	if (c == 'block') {
		jQuery('#'+target).slideUp();
		var icon = openIcon;
		var tooltip = toolTipOpen;
		jQuery.cookie(target, 'closed', {expires: 30, path: '/'});
	} else {
		jQuery('#'+target).slideDown();
		var icon = closeIcon;
		var tooltip = toolTipClose;
		jQuery.cookie(target, 'open', {expires: 30, path: '/'});
	}
	jQuery('#'+tagId).html('<img class="'+tagClass+' vtip" src="'+icon+'" title="'+tooltip+'" />');
	vtip();
}

function spjInlineTopics(target, site, spinner, tagId, openIcon, closeIcon) {
	var c=jQuery('#'+target).css('display');
	if (c == 'block') {
		jQuery('#'+target).slideUp();
		var icon = openIcon;
	} else {
		if(jQuery('#'+target).html() == '') {
			jQuery('#'+target).html('<img src="' + spinner + '" />');
			jQuery('#'+target).slideDown();
			jQuery('#'+target).load(site, function() {
				jQuery('#'+target).slideDown();
			});
		} else {
			jQuery('#'+target).slideDown();
		}
		var icon = closeIcon;
	}
	jQuery('#'+tagId).html('<img src="'+icon+'" />');
	vtip();
}

/*--------------------------------------------------------------
spjPopupImage:  Opens a popup imnage dialog (enlargement)
	source:		The image source path
*/
function spjPopupImage(source, iWidth, iHeight, limitSize) {
	/* we might need to resize it */
	var r = 0;
	var aWidth = (window.innerWidth-75);
	var aHeight = (window.innerHeight-75);

    var autoWidth = iWidth;
    var autoHeight = iHeight;

	if(limitSize) {
		/* width first */
		if(iWidth > aWidth) {
			r = (aWidth / iWidth) * 100;
			iWidth = Math.round(r * iWidth) / 100;
			iHeight = Math.round(r * iHeight) / 100;
		}
		/* now recheck height */
		if(iHeight > aHeight) {
			r = (aHeight / iHeight) * 100;
			iWidth = Math.round(r * iWidth) / 100;
			iHeight = Math.round(r * iHeight) / 100;
		}
	}

    iWidth = (autoWidth == 'auto') ? autoWidth : iWidth;
    iHeight = (autoHeight == 'auto') ? autoHeight : iHeight;

	imgSource = '<a href="' + source + '" target="_blank"><img src="' + source + '" width="'+iWidth+'" height="'+iHeight+'" /></a>';

	/* add some to container for title bar and border */
	if (iWidth != 'auto') {
		iWidth = (Math.abs(iWidth) + 10);
	}
	if (iHeight != 'auto') {
		iHeight = (Math.abs(iHeight) + 60.8);
	}

	jQuery(imgSource).dialog({
		show: 'slide',
		hide: 'clip',
		position: 'center',
		draggable: true,
		resizable: false,
		closeText: '',
		modal: true,
		closeOnEscape: true,
		width: iWidth,
		height: iHeight,
		autoOpen: true
	});
}
