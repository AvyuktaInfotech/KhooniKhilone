<?php
/*
Simple:Press
Admin Themes prepare Support Functions
$LastChangedDate: 2012-03-22 19:08:11 -0700 (Thu, 22 Mar 2012) $
$Rev: 8192 $
*/

if (preg_match('#'.basename(__FILE__).'#', $_SERVER['PHP_SELF'])) die('Access denied - you cannot directly call this file');


?>